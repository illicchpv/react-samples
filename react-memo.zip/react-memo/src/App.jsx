import {useState, memo, useMemo, useCallback} from 'react';

function Box({params, onClick}) {
  console.log('Box refresh : ', 'color: ', params.color);

  return (
    <div
      style={{
        backgroundColor: params.color,
        width: 100,
        height: 100,
        margin: 10,
      }}
      onClick={onClick}
    >Box</div>
  );
}

const MemoBox = memo(Box);
// const MemoBox = memo(Box,
//   (prevProps, nextProps) => prevProps.params.color === nextProps.params.color
// );


function App() {
  const [count, setCount] = useState(0);
  const [color, setColor] = useState('red');

  const params = useMemo(() => ({color}), [color]);
  const onClick = useCallback(() => {
    console.log('onClick');
  }, []);

  console.log('App refresh: ', 'count: ', count);

  return (
    <div className='App'>
      App

      <div>

        <button onClick={() => setCount(count + 1)}>
          count is: {count}
        </button>

        <button onClick={() => setColor(color === 'red' ? 'blue' : 'red')}>
          color: {color}
        </button>

      </div>

      <MemoBox params={params} onClick={onClick} />
      {/* <Box color='red' /> */}

    </div>
  );
}

export default App;
