import {useState} from 'react';
import {allStateIs, getErrorList, HttpGet_STATES, someStateIs, useHttpGet} from './useHttpGet';
import userUnknownImg from './assets/user-unknown.svg';

const BASE_POSTS_URL = 'https://jsonplaceholder.typicode.com/'; // err/
const BASE_IMGES_URL = 'https://randomuser.me/api/';  // err/

const globals = {
  users: [],
  images: [],
  userByUserId(userId) {
    if (!userId) return null;
    const user = this.users.find(u => u.id === userId);
    return user;
  },
  imageByUserId(userId) {
    if (!userId) return null;
    const image = this.images.find((img, i) => (i + 1) === userId);
    return image;
  },
};

export default function App() {
  const [pagePosts, setPagePosts] = useState(0);

  const urlPosts = `${BASE_POSTS_URL}posts?_page=${pagePosts}&_limit=12`;
  /* post
  {
    "userId": 1,
    "id": 1,
    "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
    "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  }
  */
  const [posts, statePosts] = useHttpGet(urlPosts);

  const urlUsers = `${BASE_POSTS_URL}users`; // const urlUsers = `${BASE_POSTS_URL}users?_page=${pageUsers}&_limit=2`;
  /* user
  {
    "id": 1,
    "name": "Leanne Graham",
    "username": "Bret",
    "email": "Sincere@april.biz",
    "address": {
      "street": "Kulas Light",
      "suite": "Apt. 556",
      "city": "Gwenborough",
      "zipcode": "92998-3874",
      "geo": {
        "lat": "-37.3159",
        "lng": "81.1496"
      }
    },
    "phone": "1-770-736-8031 x56442",
    "website": "hildegard.org",
    "company": {
      "name": "Romaguera-Crona",
      "catchPhrase": "Multi-layered client-server neural-net",
      "bs": "harness real-time e-markets"
    }
  }
  */
  const [_users, stateUsers] = useHttpGet(urlUsers);
  const usersCount = _users ? _users.length : 0;

  const urlImages = usersCount ? `${BASE_IMGES_URL}?inc=gender,name,picture&results=${usersCount}&seed=test&format=pretty` : ''; // &gender=male
  /* images
  {
    "results": [
      {
        "gender": "male",
        "name": {
          "title": "Mr",
          "first": "Juan",
          "last": "Uribe"
        },
        "picture": {
          "large": "https://randomuser.me/api/portraits/men/56.jpg",
          "medium": "https://randomuser.me/api/portraits/med/men/56.jpg",
          "thumbnail": "https://randomuser.me/api/portraits/thumb/men/56.jpg"
        }
      },
      ...
    ],
    "info": {
      "seed": "d6b04b6434c2e95d",
      "results": 5,
      "page": 1,
      "version": "1.4"
    }
  }
  */
  useHttpGet(urlImages, null, (data, dataState) => {
    if (data) {
      globals.users = [..._users];
      globals.images = [...data.results];
      for (const user of globals.users) {
        user.photo = globals.imageByUserId(user.id)?.picture?.thumbnail;
      }
    }
    if (someStateIs(HttpGet_STATES.ERROR, [dataState])) {
      console.log('onResult dataState: ', dataState);
    }
  });

  return (
    <>
      <div className='App'>

        <h1>
          Posts page:
          <span>{pagePosts}</span>

          <button onClick={async () => {
            setPagePosts(p => p + 1);
          }}>Next 1</button>

          <button onClick={async () => {
            setPagePosts(p => p + 1);
            await _wait(0);
            setPagePosts(p => p + 1);
          }}>Next 2</button>

          <button onClick={() => setPagePosts(0)}>Back 0</button>
        </h1>
        <hr />

        {someStateIs(HttpGet_STATES.INIT, [statePosts, stateUsers]) &&
          <ul className='init'><li>init...</li></ul>}

        {someStateIs(HttpGet_STATES.LOADING, [statePosts, stateUsers]) &&
          <ul className='loading'><li>loading...</li></ul>}

        {someStateIs(HttpGet_STATES.ERROR, [statePosts, stateUsers]) &&
          <ul className='err'><li>
            {
              getErrorList([statePosts, stateUsers]).reduce((a, c) => <>{a}👉{c}<br /></>, null)
            }
          </li></ul>}

        {allStateIs(HttpGet_STATES.IDLE, [statePosts, stateUsers]) &&
          <ul>
            <li>Page: {pagePosts}</li>

            {posts.length > 0 && posts.map(post => (
              <li key={post.id}>
                {post.title}
                <User post={post} />
              </li>
            ))}

            {posts.length <= 0 &&
              <li><h2>No records</h2></li>
            }
          </ul>
        }
      </div>
    </>
  );
}

function User({post}) {
  const user = globals.userByUserId(post.userId);
  const userName = user ? user.name : 'Unknown';
  const userImage = (user && user.photo) ?
    <img src={user.photo} alt='user face' /> :
    <img src={userUnknownImg} alt='user face' />;

  return (<>
    <i>
      {userImage}
      {userName} (userId:{post.userId})
    </i>
  </>);
}

// ------------------------

const _wait = (v) => new Promise(resolve => setTimeout(() => resolve(), v * 4));