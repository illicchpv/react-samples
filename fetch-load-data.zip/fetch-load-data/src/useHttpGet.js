import {useEffect, useRef, useState} from "react";

const showLog = false;
const showWarn = true;
const showErr = true;

const addWait = false;

/**
 * Description HttpGet_STATES
 *
 * @type {{ INIT: string; IDLE: string; LOADING: string; ERROR: string; }}
 */
export const HttpGet_STATES = {
  INIT: 'init::',
  IDLE: 'idle::',
  LOADING: 'loading::',
  ERROR: 'error::',
};

/**
 * Description someStateIs- one or more state in [states] = stateValue
 * @exports someStateIs
 * @param {string} stateValue 
 * @param {[string]} states 
 * @returns {boolean} 
 */
export const someStateIs = (stateValue, states) => states.some(s => s.startsWith(stateValue));

/**
 * Description allStateIs - all state in [states] = stateValue
 * @exports allStateIs
 * @param {string} stateValue 
 * @param {[string]} states 
 * @returns {boolean} 
 */
export const allStateIs = (stateValue, states) => states.every(s => s.startsWith(stateValue));

/**
 * Description stateIs
 * @exports stateIs
 * @param {string} stateValue 
 * @param {string} state 
 * @returns {boolean} 
 */
export const stateIs = (stateValue, state) => state.startsWith(stateValue);

/**
 * Description getErrorList
 * @exports getErrorList
 * @param {[string]} states 
 * @returns {[string]} errors array
 */
export const getErrorList = (states) => {
  return states.map(el => el.split(HttpGet_STATES.ERROR)[1]).reduce((a, c) => {
    if (c) a.push(c.trim());
    return a;
  }, []);
};

const optionsDefault = {
  method: "GET",
  headers: {
    "Content-Type": "application/json",
  },
};
/**
 * Description useHttpGet
 * @exports useHttpGet
 * @param {string} url - page URL
 * @param {object | null} headers
 * @param {function | null} onResult
 * @returns {[any, string]} [data, status]
 */
export function useHttpGet(url, headers = null, onResult = null) {
  const abortController = useRef(null);
  const [data, setPosts] = useState(null);
  const [state, setState] = useState(HttpGet_STATES.INIT);
  _log('state: ', state);
  let step = '';

  useEffect(() => {
    if (!url) {
      setState(HttpGet_STATES.IDLE);
      return;
    }

    (async () => {
      abortController.current?.abort();
      abortController.current = new AbortController();

      const newParams = {...optionsDefault, headers: {...optionsDefault.headers, ...headers}};
      newParams.signal = abortController.current?.signal;
      try {
        // if(url.includes('/posts?'))
        //   debugger
        setState(HttpGet_STATES.LOADING);
        const response = await fetch(url, newParams);
        if (response.status >= 400)
          throw new Error(`response.status ${response.status}`);
        await _wait(100);
        step = 'parse JSON.';
        const data = await response.json();
        setPosts(data);
        setState(HttpGet_STATES.IDLE);
        _log('Posts OK ');
        onResult?.(data, HttpGet_STATES.IDLE);
      } catch (e) {
        if (e.name === 'AbortError') {
          _logWarn('Request aborted');
          return;
        }
        const msg = `${HttpGet_STATES.ERROR} ${step} ${e.toString().replaceAll('TypeError:', '')} - url:[${url}]`;
        _logErr(msg);
        setState(msg);
        onResult?.(data, msg);
      }
    })();
  }, [url]);

  return [data, state];
}

// ----------------------------------------

const _log = showLog ? console.log.bind(console, 'useHttpGet>') : () => { };
const _logWarn = showWarn ? console.log.bind(console, '👉useHttpGet>') : () => { };
const _logErr = showErr ? console.log.bind(console, '🐞useHttpGet>') : () => { };

const _wait = addWait ? (v) => new Promise(resolve => setTimeout(() => resolve(), v * 4)) : () => { };
