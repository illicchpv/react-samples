### Напишем приложение показывающее сообщения пользователей, и некоторые данные про пользователей.

  выглядеть приложение будет примерно так:  
    ![alt text](image.png)

### Данные берём: 
  https://jsonplaceholder.typicode.com/   
    сами сообщения(posts) и профили пользователей(users) 

  т.к. фото пользователей это api не предоставляет, то фото будем брать из

  https://randomuser.me/api/  
    связь будет такая: randomuser.users[(jsonplaceholder.userId)]  
    т.е. userId будет использоваться как индекс в массиве информаций о пользователях (там есть URL на фото)  
    взятый с randomuser

  для получения данных будем использовать самопальный хук useHttpGet.  

  для начала я расскажу о хуке useHttpGet.  
  потом будем его применять для построения требуемого приложения.

  React, useState, useEffect, async, await, fetch method GET, AbortController, abort, batching, jsonplaceholder, randomuser, 

---
# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh
