import {useUrlHash} from "./useUrlHash";

const langs = ['ru', 'en', 'jp'];

function App() {
  console.log('App render');

  return (
    <section>
      <div>App</div>

      <LanguageSwitcher />
      <Counter />

      <Level11 />

      <Level12 />
    </section>
  );
}
export default App;

// ---------- components

const useUrlHashLang = () => useUrlHash('lang', langs[0]);
const useUrlHashCount = () => useUrlHash('count', 0);

function LanguageSwitcher() {
  const [lang, setLang] = useUrlHashLang();

  return (<>
    <div>
      {langs.map((l) => <button disabled={lang === l} key={l} onClick={() => setLang(l)}>{l}</button>)}
    </div>
  </>);
}

function Counter() {
  const [count, setCount] = useUrlHashCount();

  return (<>
    <button onClick={() => setCount(e => e - 1)}> -- </button>
    {count}
    <button onClick={() => setCount(e => e + 1)}> ++ </button>
  </>);
}

function Level11() {
  console.log('Level-11 render');

  return (
    <section>
      <div>Component Level-11</div>
      <Level2 />
    </section>
  );
}

function Level12() {
  console.log('Level-12 render');
  const [lang] = useUrlHashLang();
  const [count] = useUrlHashCount();

  return (
    <section>
      <div>Component Level-12 <b>count: {count} lang: {lang}</b></div>
    </section>
  );
}

function Level2() {
  console.log('Level-2 render');

  return (
    <section>
      <div>Component Level-2</div>
      <Level3 />
    </section>
  );
}

function Level3() {
  console.log('Level-3 render');

  return (
    <section>
      <div>Component Level-3</div>
      <LanguageSwitcher />
    </section>
  );
}
