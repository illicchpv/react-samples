import {useEffect, useState} from "react";

/**
 * Description useUrlHash
 *
 * @export useUrlHash
 * @param {*} name - название параметра хэша(count👉) http://localhost:5175/#count=16
 * @param {string} [defNameVal=''] - значение параметра по умолчанию
 * @returns {{}} [hashNameV, setHashNameV]
 * // const [testVal, setTestVal] = useUrlHash('test', 1);
 * // const [counterVal, setCounterVal] = useUrlHash('counter', 0);
 */
export function useUrlHash(name, defNameVal = '') {
  const [hashNameV, setHashNameV] = useState(getUrlHashParam(name, defNameVal));

  useEffect(() => {
    const onPop = e => {
      setHashNameV(getUrlHashParam(name, defNameVal));
    };
    window.addEventListener('popstate', onPop);

    const onChange = e => {
      const {hash} = URL.parse(e.detail.url);
      const val = hashToParamValue(hash, name, defNameVal);
      setHashNameV(val);
    };
    document.addEventListener('onChangeUrl', onChange);

    return () => {
      console.log('remove popstate, onChangeUrl ');
      window.removeEventListener('popstate', onPop);
      document.removeEventListener('onChangeUrl', onChange);
    };
  }, []);

  const setHashNameVal = (newVal) => {
    if (typeof newVal === 'function')
      newVal = newVal(hashNameV);
    setUrlHashParam(name, newVal, defNameVal);
    setHashNameV(newVal);
  };

  return [hashNameV, setHashNameVal];
}

function getUrlHashParam(paramName, def = '') {
  const {hash} = window.location;
  return hashToParamValue(hash, paramName, def);
}

function hashToParamValue(hash, paramName, def = '') {
  if (hash === '') return def;
  let v = hash.replaceAll('#', '').split(`${paramName}=`)[1];
  if (v === undefined) return def;
  v = v.split('&')[0].trim();
  if (isNumeric(def)) {
    v = +v;
    if (isNaN(v)) v = def;
  }
  return v;
}

function setUrlHashParam(paramName, newVal, defNameVal = '') {
  if (!paramName) { // хотелось очистить историю, не получается
    window.history.replaceState(null, null, window.location.href);
    return;
  }

  let rezHash = '#';
  const {hash, origin, pathname} = window.location;
  if (hash.indexOf(`${paramName}=`) < 0) {
    if (newVal !== defNameVal) {
      rezHash = hash ? `${hash}&${paramName}=${newVal}` : `#${paramName}=${newVal}`;
    } else {
      rezHash = hash;
    }
  } else {
    const nameVals = hash.replaceAll('#', '').split('&');
    for (const nameVal of nameVals) {
      const [name, val] = nameVal.split('=');
      if (!name) continue;
      if (name === paramName) {
        if (newVal !== null && newVal !== defNameVal) rezHash += `${paramName}=${newVal}&`;
      } else {
        rezHash += `${name}=${val}&`;
      }
    }
    rezHash = rezHash.substring(0, rezHash.length - 1);
    rezHash = rezHash === '#' ? '' : rezHash;
  }

  const nUrl = origin + pathname + rezHash;
  window.history.pushState(null, null, window.location);
  changeUrlWithEvent(null, null, nUrl);
}

function changeUrlWithEvent(state, title, url) {
  var pushChangeEvent = new CustomEvent("onChangeUrl", {
    detail: {
      state,
      title,
      url
    }
  });
  document.dispatchEvent(pushChangeEvent);
  window.history.replaceState(state, title, url);
}

function isNumeric(value) {return /^-?\d+$/.test(value);}


