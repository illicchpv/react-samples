познакомлю с самопальным 'state manager' основанном на работе с URL. с хеш частью URL

---
'state manager', 'props drilling', nuqs, useState, window.history.pushState, window.history.replaceState 

---

например если в URL хранится счетчик и язык

http://localhost:5175/#count=29&lang=jp

то любой компонент приложения может эти параметры получить. вне зависимости от вложенности.
так что это наверно можно назвать глобальным хранилищем состояния приложения.
Такой подход тем более удобен тем что URL можно кому-то послать и тот перейдёт именно в нужное место программы.

Это маленький аналог https://www.npmjs.com/package/nuqs


---
# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh
